#/system/bin/bash
#
finish() {
    killall com.google.android.gms >> /dev/null
    killall com.google.android.gms.unstable >> /dev/null
    echo "> Success Installed."
}
#
vc() {
if [ "$BOOTMODE" ] && [ "$KSU" ]; then
    ui_print "> Installation with KSU v$KSU_KERNEL_VER($KSU_KERNEL_VER_CODE)"
elif [ "$BOOTMODE" ] && [ "$APATCH" ]; then
    ui_print "> Installation with Apatch v$APATCH_VER($APATCH_VER_CODE)"
elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
    ui_print "> Installation with Magisk v$MAGISK_VER($MAGISK_VER_CODE)"
else 
    ui_print "> Dangerous action detected!"
    ui_print "> Aborting..."
    abort "> Aborted!"  
fi
}
#
available() {
    if [ "$BOOTMODE" ] && [ "$KSU" ]; then
        echo """
if [ -d /data/adb/modules/tricky_store ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ✅Tricky Store] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
else
    sed -i 's/^description=.*/description=[❌ Environment not supported] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
fi""" >> $MODPATH/post-fs-data.sh
    elif [ "$BOOTMODE" ] && [ "$APATCH" ]; then
        echo """
if [ -d /data/adb/modules/tricky_store ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ✅Tricky Store] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
else
    sed -i 's/^description=.*/description=[❌ Environment not supported] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
fi""" >> $MODPATH/post-fs-data.sh
    elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ] && [ $MAGISK_VER_CODE -lt 27008 ]; then
        echo """
if [ ! -d /data/adb/modules/zygisk_shamiko ] || [ -d /data/adb/modules/zygisk_shamiko ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ✅Tricky Store] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
else
    sed -i 's/^description=.*/description=[❌ Environment not supported] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
fi
""" >> $MODPATH/post-fs-data.sh
    else
        echo """
if [ -d /data/adb/modules/tricky_store ] && [ -d /data/adb/modules/zygisk_shamiko ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ✅Tricky Store. ✅Shamiko] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
elif [ ! -d /data/adb/modules/tricky_store ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ❌Tricky Store. ✅Shamiko] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
elif [ ! -d /data/adb/modules/zygisk_shamiko ]; then
    sed -i 's/^description=.*/description=[😋Working as Support for: ✅Tricky Store. ❌Shamiko] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
else
    sed -i 's/^description=.*/description=[❌ Environment not supported] Support module for TrickyStore and Shamiko./' \"/data/adb/modules/tsupport/module.prop\"
fi""" >> $MODPATH/post-fs-data.sh
    fi
}
#
spoof() {
#This code for lazy people, tired making this to a script, but that what script suppose to be, an automation.
    echo """
if magisk --denylist status || { 
    [ ! -f /data/adb/modules/zygisk_shamiko/disable ] && 
    [ ! -d /data/adb/modules/zygisk_shamiko ] || 
    { 
        [ -d /data/adb/modules/zygisk_shamiko ] && 
        [ ! -f /data/adb/modules/zygisk_shamiko/disable ]; 
    }; 
}; then
    packages=\"com.zhenxi.hunter com.reveny.nativecheck krypton.tbsafetychecker io.github.vvb2060.mahoshojo\"
    procc=\"com.zhenxi.hunter_zygote io.github.vvb2060.mahoshojo_zygote\"
    
    for package in \$packages
    do
        if pm list packages | grep \"\$package\" > /dev/null; then
            for proc in \$procc
            do
                if echo \"\$proc\" | grep \"\$package\" > /dev/null; then
                    magisk --denylist add \"\$package\"       
                    magisk --denylist add \"\$package\" \"\$proc\"
                else
                    magisk --denylist add \"\$package\"
                fi
            done
        fi
    done
fi""" >> $MODPATH/service.sh

TARGET_DIR="/data/adb/tricky_store"
TARGET_FILE="$TARGET_DIR/target.txt"
TARGET_BACKUP="$TARGET_DIR/target.txt.bak"
    
if [ -d "$TARGET_DIR" ]; then
    if [ -f "$TARGET_FILE" ]; then
        if [ -f "$TARGET_BACKUP" ]; then
            su -c rm -rf "$TARGET_FILE"
        else
            su -c mv "$TARGET_FILE" "$TARGET_BACKUP"
        fi
    fi
    
    packages=$(su -c pm list packages | awk -F: '{print $2}')
    
    for package in $packages; do
        echo "$package!" >> "$TARGET_FILE"
    done
fi

if [ -d /data/adb/modules/hosts ]; then
    ui_print "! Systemless Host module detected!"
    sleep 0.5
    ui_print "> Switch to TSupport systemless host."
    mkdir -p $MODPATH/system/etc
    mv /data/adb/modules/hosts/system/etc/hosts $MODPATH/system/etc/hosts

    if grep -q "attestation.reveny.me" "$MODPATH/system/etc/hosts"; then
        sed -i 's/.*attestation.reveny.me.*/127.0.0.1       attestation.reveny.me/' "$MODPATH/system/etc/hosts"
    else
        sed -i '$a 127.0.0.1       attestation.reveny.me' "$MODPATH/system/etc/hosts"
    fi

    touch /data/adb/modules/hosts/remove
elif [ -f /data/adb/modules/tsupport/system/etc/hosts ]; then
    ui_print "! Old TSupport Host Found!"
    mkdir -p $MODPATH/system/etc
    cp /data/adb/modules/tsupport/system/etc/hosts $MODPATH/system/etc/hosts
    sleep 0.5
    ui_print "> Moving Host Setting to New TSupport."
    mv /data/adb/modules/hosts/system/etc/hosts $MODPATH/system/etc/hosts

    if grep -q "attestation.reveny.me" "$MODPATH/system/etc/hosts"; then
        sed -i 's/.*attestation.reveny.me.*/127.0.0.1       attestation.reveny.me/' "$MODPATH/system/etc/hosts"
    else
        sed -i '$a 127.0.0.1       attestation.reveny.me' "$MODPATH/system/etc/hosts"
    fi
else
    mkdir -p $MODPATH/system/etc
    su -c cp /system/etc/hosts $MODPATH/system/etc/hosts

    if grep -q "attestation.reveny.me" "$MODPATH/system/etc/hosts"; then
        sed -i 's/.*attestation.reveny.me.*/127.0.0.1       attestation.reveny.me/' "$MODPATH/system/etc/hosts"
    else
        sed -i '$a 127.0.0.1       attestation.reveny.me' "$MODPATH/system/etc/hosts"
    fi
fi
}
#
tsu() {
    echo """MODPATH=\"\${0%/*}\"

if [ -d /data/adb/modules/tricky_store ] && [ -f /data/adb/modules/tsupport/.nomedia ]; then
    [ -f /data/adb/tricky_store/keybox.xml.bak ] && rm -rf /data/adb/tricky_store/keybox.xml.bak
    [ -f /data/adb/tricky_store/keybox.xml ] && mv /data/adb/tricky_store/keybox.xml /data/adb/tricky_store/keybox.xml.bak
    cp /data/adb/modules/tsupport/.nomedia /data/adb/tricky_store/keybox.xml
elif [ ! -d /data/adb/modules/tricky_store ]; then
    [ -d /data/adb/tricky_store ] && rm -rf /data/adb/tricky_store
    [ ! -d /data/adb/modules/zygisk_shamiko ] && touch /data/adb/modules/tsupport/remove
fi
""" >> $MODPATH/post-fs-data.sh
}
#
shamsu() {
    if [ -f $MODPATH/.logs ]; then
        echo """
if [ -d /data/adb/modules/zygisk_shamiko ]; then
    if [ -f /data/adb/modules/tsupport/.logs ]; then
        [ -f /data/adb/modules/tsupport/action.sh ] && rm -rf /data/adb/modules/action.sh
        cp /data/adb/modules/tsupport/.logs /data/adb/modules/tsupport/action.sh
    else
        echo \"echo \"! Something wrong, Please Reinstall.\" && sleep 2.8\" > /data/adb/modules/tsupport/action.sh
    fi  
else
    if [ -f /data/adb/modules/tsupport/action.sh ]; then
        rm -rf /data/adb/modules/tsupport/action.sh
    fi
    rm -rf /data/adb/shamiko
fi""" >> $MODPATH/post-fs-data.sh
    else
        abort "! Suspend Something Wrong, Please Reinstall."
    fi
}
#
pisu() {
    if [ -d /data/adb/modules/playintegrityfix ] && grep -q "Play Integrity Fork" "/data/adb/modules/playintegrityfix/module.prop"; then
        ui_print "! PIF Fork Detected"
        sleep 0.5
        ui_print "> Adding support for PIFF"
        if [ -f $MODPATH/.fippff ]; then
            [ -f /data/adb/modules/playintegrityfix/custom.pif.json ] && su -c rm -rf /data/adb/modules/playintegrityfix/custom.pif.json
            [ ! -f /data/adb/modules/playintegrityfix/custom.pif.json ] && su -c cp $MODPATH/.fippff /data/adb/modules/playintegrityfix/custom.pif.json
            su -c mv $MODPATH/.fippff $MODPATH/.fippff-online
        else
            [ -f $MODPATH/.fippff-online ] && su -c mv $MODPATH/.fippff-online $MODPATH/.fippff
            [ ! -f $MODPATH/.fippff ] && ui_print "! Something wrong, please reinstall."
        fi
    fi
    echo """
if [ -d /data/adb/modules/playintegrityfix ]; then
    if grep -q \"Play Integrity Fork\" \"/data/adb/modules/playintegrityfix/module.prop\"; then
        if [ -f \$MODPATH/.fippff ]; then
            [ -f /data/adb/modules/playintegrityfix/custom.pif.json ] && su -c rm -rf /data/adb/modules/playintegrityfix/custom.pif.json
            [ ! -f /data/adb/modules/playintegrityfix/custom.pif.json ] && su -c cp \$MODPATH/.fippff /data/adb/modules/playintegrityfix/custom.pif.json
            su -c mv \$MODPATH/.fippff \$MODPATH/.fippff-online
        fi
    else
        [ -f \$MODPATH/.fippff-online ] && mv \$MODPATH/.fippff-online \$MODPATH/.fippff
        if [ -f /data/adb/modules/playintegrityfix/old.pif.json ]; then
            [ -f /data/adb/modules/playintegrityfix/pif.json ] && su -c rm -rf /data/adb/modules/playintegrityfix/pif.json
            su -c cp /data/adb/modules/tsupport/.fip /data/adb/modules/playintegrityfix/pif.json
        elif [ ! -f /data/adb/modules/playintegrityfix/old.pif.json ]; then
            [ -f /data/adb/modules/playintegrityfix/pif.json ] && su -c mv /data/adb/modules/playintegrityfix/pif.json /data/adb/modules/playintegrityfix/old.pif.json
            su -c cp /data/adb/modules/tsupport/.fip /data/adb/modules/playintegrityfix/pif.json
        fi
    fi
else
    [ -f \$MODPATH/.fippff-online ] && su -c mv \$MODPATH/.fippff-online \$MODPATH/.fippff
fi
""" >> $MODPATH/post-fs-data.sh
    echo """
if [ -d /data/adb/modules/playintegrityfix ]; then
    [ -f /data/adb/modules/playintegrityfix/pif.json ] && [ -f /data/adb/modules/playintegrityfix/old.pif.json ] && su -c rm -rf /data/adb/modules/playintegrityfix/pif.json && su -c mv /data/adb/modules/playintegrityfix/old.pif.json /data/adb/modules/playintegrityfix/pif.json
fi
if [ -d /data/adb/tricky_store ]; then
    [ -f /data/adb/tricky_store/target.txt ] && [ -f /data/adb/tricky_store/target.txt.bak ] && su -c rm -rf /data/adb/tricky_store/target.txt
    [ -f /data/adb/tricky_store/target.txt.bak ] && su -c mv /data/adb/tricky_store/target.txt.bak /data/adb/tricky_store/target.txt
fi
""" >> $MODPATH/uninstall.sh
}
#
tee() {
    echo """
if [ -d /data/adb/tricky_store ]; then
    if [ -f /data/adb/tricky_store/tee_status ]; then
        if grep -q \"teeBroken=true\" /data/adb/tricky_store/tee_status && grep -q \"com.google.android.gms\" \"/data/adb/tricky_store/target.txt\" ; then
            sed -i 's/^com.google.android.gms.*/com.google.android.gms!/' \"/data/adb/tricky_store/target.txt\"
            sed -i 's/^io.github.vvb2060.keyattestation.*/io.github.vvb2060.keyattestation!/' \"/data/adb/tricky_store/target.txt\"
        elif grep -q \"teeBroken=false\" /data/adb/tricky_store/tee_status && grep -q \"com.google.android.gms\" \"/data/adb/tricky_store/target.txt\" ; then
            sed -i 's/^com.google.android.gms.*/com.google.android.gms/' \"/data/adb/tricky_store/target.txt\"
            sed -i 's/^io.github.vvb2060.keyattestation.*/io.github.vvb2060.keyattestation/' \"/data/adb/tricky_store/target.txt\"
        else
            grep -q \"teeBroken=true\" /data/adb/tricky_store/tee_status && echo \"com.google.android.gms!\" >> /data/adb/tricky_store/target.txt 
            grep -q \"teeBroken=true\" /data/adb/tricky_store/tee_status && echo \"io.github.vvb2060.keyattestation!\" >> /data/adb/tricky_store/target.txt 
            grep -q \"teeBroken=false\" /data/adb/tricky_store/tee_status && echo \"com.google.android.gms\" >> /data/adb/tricky_store/target.txt 
            grep -q \"teeBroken=false\" /data/adb/tricky_store/tee_status && echo \"io.github.vvb2060.keyattestation\" >> /data/adb/tricky_store/target.txt 
        fi
    fi
fi 
""" >> $MODPATH/post-fs-data.sh
}
#
inject() {
    # Remove XiaomiEU
    if pm list packages | grep eu.xiaomi.module.inject >> /dev/null; then
        ui_print "! EU ROM Detected"
        if pm list packages -d | grep eu.xiaomi.module.inject >> /dev/null; then
            ui_print "> EU ROM already Fixed."
            sleep 1
        else
            ui_print "> Initialize EU Fix.."
            su -c pm disable eu.xiaomi.module.inject >> /dev/null
            sleep 1
        fi       
    fi
# Remove EliteRoms app

    if [ -d "/system/app/XInjectModule" ]; then
        
        directory="$MODPATH/system/app/XInjectModule"
        
        [ -d "$directory" ] || mkdir -p "$directory"
        
        touch "$directory/.replace"
        
        ui_print "> Remove XInjectModule app."
    fi
    
    if [ -d "/system/app/EliteDevelopmentModule" ]; then
        
        directory="$MODPATH/system/app/EliteDevelopmentModule"
        
        [ -d "$directory" ] || mkdir -p "$directory"
        
        touch "$directory/.replace"
        
        ui_print "> Remove EliteDevelopmentModule app."
    fi
}
#
check3() {
    if [ -f "$MODPATH/.nomedia" ] && [ -f "$MODPATH/.logs" ]; then
        if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
            mv /data/adb/tricky_store/keybox.xml /data/adb/tricky_store/keybox.xml.bak
        fi
        tsu
        shamsu
        pisu
        tee
        spoof
        inject
        available
        finish
    else
        abort "! Suspend. Something Wrong, Please Reinstall."
    fi
}
#
check2() {
    if [ -d /data/adb/modules/zygisk_shamiko ]; then
        ui_print "> Shamiko Detected!"
        sleep 0.5
        [ $MAGISK_VER_CODE -lt 27008 ] && abort "! Install Magisk v27.0(27008)+ for Shamiko Support, current version is v$MAGISK_VER($MAGISK_VER_CODE)"
        ui_print "> Working as Shamiko Support"
        tsu
        shamsu
        pisu
        tee
        spoof
        inject
        available
        finish
    else
        abort "! Shamiko and Tricky Store not Detected!"
        sleep 0.5
    fi
    
}
#
check() {
    if [ -d "/data/adb/modules/tricky_store" ]; then
        ui_print "> TrickyStore Detected!" | ui_print "> Adapting..."
        sleep 0.5
        if [ -f "/data/adb/tricky_store/keybox.xml.bak" ]; then
            ui_print "! Old Trace Detected!"
            ui_print "> Cleaning Trace"
            rm "/data/adb/tricky_store/keybox.xml.bak"
        fi
        sleep 0.5
        check3
    else
        ui_print "! TrickyStore not detected"
        check2
    fi
}
#
start() {
    ui_print """
==========================================================
Citra, a standalone implementation, leaves a trace in IoT.
==========================================================
https://t.me/citraintegritytrick
==========================================================
"""
    sleep 0.3
    vc
    ui_print "> Initialization.."
    #
    if ! grep -q "id=tsupport" $MODPATH/module.prop ; then
        abort "! Suspend. Something Wrong, Please Reinstall."
    fi
    sleep 1
    echo "sleep 18 && su -c resetprop ro.build.selinux 2" >> $MODPATH/service.sh   
    check
}
#
start